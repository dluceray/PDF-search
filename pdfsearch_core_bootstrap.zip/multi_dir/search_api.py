
from typing import List, Optional, Dict, Any
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from .config import MultiDirConfig
from .aggregator import MultiDirAggregator

router = APIRouter()

# In-process singleton (the host app can rebind via /reload)
_state = {
    "cfg": None,       # type: Optional[MultiDirConfig]
    "aggr": None,      # type: Optional[MultiDirAggregator]
}

class ConfigPayload(BaseModel):
    roots: List[str]
    excel_patterns: Optional[List[str]] = None
    allowed_exts: Optional[List[str]] = None
    schema_hints: Optional[Dict[str, Dict[str, str]]] = None

class SearchPayload(BaseModel):
    project_like: Optional[str] = None
    unit_like: Optional[str] = None
    sign_method: Optional[str] = None
    sign_date_like: Optional[str] = None  # 'YYYY' or 'YYYY-MM' or 'YYYY-MM-DD'
    contract_no_like: Optional[str] = None
    limit: int = 200

@router.get("/config", response_model=ConfigPayload)
def get_config() -> Any:
    if _state["cfg"] is None:
        raise HTTPException(status_code=404, detail="Multi-directory config not initialised.")
    cfg = _state["cfg"]
    return ConfigPayload(
        roots=cfg.roots,
        excel_patterns=cfg.excel_patterns,
        allowed_exts=cfg.allowed_exts,
        schema_hints=cfg.schema_hints or {},
    )

@router.post("/reload")
def reload_config(payload: ConfigPayload) -> Dict[str, Any]:
    cfg = MultiDirConfig(
        roots=payload.roots,
        excel_patterns=payload.excel_patterns or MultiDirConfig([]).excel_patterns,
        allowed_exts=payload.allowed_exts or MultiDirConfig([]).allowed_exts,
        schema_hints=payload.schema_hints or {},
    )
    aggr = MultiDirAggregator(cfg)
    aggr.load()
    _state["cfg"] = cfg
    _state["aggr"] = aggr
    return {
        "ok": True,
        "records_loaded": len(aggr.records()),
        "roots": cfg.roots,
    }

@router.post("/search")
def search(payload: SearchPayload) -> Dict[str, Any]:
    if _state["aggr"] is None:
        raise HTTPException(status_code=400, detail="Not loaded. Call /api/mdirs/reload first.")
    items = _state["aggr"].search(
        project_like=payload.project_like,
        unit_like=payload.unit_like,
        sign_method=payload.sign_method,
        sign_date_like=payload.sign_date_like,
        contract_no_like=payload.contract_no_like,
        limit=payload.limit,
    )
    # Output fields order normalized
    return {
        "count": len(items),
        "items": items,
    }
