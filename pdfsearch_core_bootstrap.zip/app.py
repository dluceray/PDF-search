
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
import logging, uvicorn, os, time, uuid

app = FastAPI(title="PDF Contract Search System", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger("app")

@app.middleware("http")
async def add_traceid_logger(request: Request, call_next):
    trace_id = request.headers.get("X-Trace-Id", str(uuid.uuid4()))
    start = time.time()
    try:
        response = await call_next(request)
        return response
    finally:
        cost = int((time.time()-start)*1000)
        logger.info("trace=%s %s %s %dms", trace_id, request.method, request.url.path, cost)

@app.get("/api/health")
def health():
    return {"ok": True, "ts": int(time.time())}

try:
    from module5.multi_dir import search_router as mdirs_router
    app.include_router(mdirs_router, prefix="/api/mdirs")
except Exception as e:
    logger.warning("Module5 not mounted: %s", e)

try:
    from module4_ai.routes import router as ai_router
    app.include_router(ai_router, prefix="/api/ai")
except Exception as e:
    logger.warning("Module4 not mounted: %s", e)

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=int(os.getenv("PORT", "8000")))
